<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand" href="#">Matz Accounts</a>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="updates.php">Home
                        <span class="sr-only">(current)</span>
                    </a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="category.php">Category
                    </a>
                </li>
                <!-- <li class="nav-item active">
                    <a class="nav-link" href="designation.php">Designation
                    </a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="faculty.php">Academic Unit
                    </a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="dept.php">Department
                    </a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="emp.php">Employees
                    </a>
                </li>
                <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Panels
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <a class="dropdown-item" href="home.php">Admin Panel</a>
                            <a class="dropdown-item" href="../academics panel/">Academic Panel</a>
                        </div>
                    </li> -->
                <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
            </ul>
        </div>
    </nav>