<?php
include "conn/conn.php";
session_start();
if (!isset($_SESSION['login_user'])) {
    header("Location:index.php");
}
// if(isset($_SESSION['login_user'])){
//     if((time() - $_SESSION['timestamp']) > 900) // 900 = 15 * 60  
//     {  
//         header("location: ../logout.php");  
//     }  
//     else  
//     {  
//         $_SESSION['timestamp'] = time();  
//     }  
// }
// if ($_SESSION['desg'] != "admin") {
//     header("Location:../logout.php");
// }

if (isset($_POST['submit'])) {

    if (!empty($_POST['cname'])) {
        $cname=$_POST['cname'];
        $sql2="SELECT * FROM category WHERE CName='$cname'";
        $result=$conn->query($sql2);
        if ($result->num_rows > 0) {
            echo "<script> alert('Category Already Exist! Please Enter Another One') </script>";
            echo "<script>setTimeout(\"location.href = 'addcategory.php';\",100);</script>";
        }
        else{
            $sql="INSERT INTO category (CName) VALUES('$cname')";
            if ($conn->query($sql) === TRUE) 
            {
                echo "<script> alert('Category Created Successfully') </script>";
                echo "<script>setTimeout(\"location.href = 'addcategory.php';\",100);</script>";
            } 
            else 
            {
                echo "Error Adding Category: " . $conn->error;
                echo "<script>setTimeout(\"location.href = 'addcategory.php';\",100);</script>";
            }
        }
    }
    else{
        echo "<script> alert('Please Fill all the Required Feilds') </script>";
    }
}
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
            crossorigin="anonymous">
            <link rel="stylesheet" href="../bs.css">
        <title>Matz</title>
    </head>

    <body>
        <?php include "navbar.php"; ?>
        <div class="container" id="main-body">
        <h1 class="text-center m-3">Add Category</h1>
            <form action="addcategory.php" method="post">
                <div style="margin-top: 15px;">
                    <table class="table table-hover">
                        <tr>
                            <td>Category Name:</td>
                            <td>  
                                <input type="text" name="cname" class="form-control" value="">
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                            <button type="submit" name="submit" class="btn btn-primary btn-md">Add Category</button>
                            &nbsp;
                            <a href="category.php" class="btn btn-success" role="button" aria-pressed="true">Back to Category</a>
                            </td>
                        </tr>
                    </table>
                </div>
            </form>

        </div>




        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
            crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
            crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
            crossorigin="anonymous"></script>
    </body>

    </html>