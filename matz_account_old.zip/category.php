<?php
include "conn/conn.php";
session_start();
if (!isset($_SESSION['login_user'])) {
    header("Location:index.php");
}
// if(isset($_SESSION['login_user'])){
//     if((time() - $_SESSION['timestamp']) > 900) // 900 = 15 * 60  
//     {  
//         header("location: ../logout.php");  
//     }  
//     else  
//     {  
//         $_SESSION['timestamp'] = time();  
//     }  
// }
// if ($_SESSION['desg'] != "admin") {
//     header("Location:../logout.php");
// }
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
                    crossorigin="anonymous"></script> -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script> -->
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
            crossorigin="anonymous">
        <link rel="stylesheet" href="../bs.css">
        <title>Matz</title>
        <style>
            td,tr,th{
                text-align : center;
            }
        </style>
    </head>

    <body>
        <?php include "navbar.php"; ?>
        <div class="container" id="main-body">
            <h1 class="text-center m-3">Categories</h1>
            <div>
                <a href="addcategory.php" class="btn btn-outline-primary mb-3" role="button" style="margin-top: 10px;" aria-pressed="true">Add Category</a>
            </div>

            <div style="max-height:100vh;width:82vw; overflow-x: auto; overflow-y: auto;" id="task_table">
                <table class="table table-hover">
                    <tr class="table-primary bg-primary">
                        <th style="text-align : center">Action</th>
                        <!-- <th style="text-align : center">Task ID</th> -->
                        <th style="text-align : center">Category</th>
                    </tr>

                    <?php
                        $sql = "SELECT * FROM category";
                        $result=$conn->query($sql);
                        if ($result->num_rows > 0) {
                        // output data of each row
                            while($row = $result->fetch_assoc()) {
                                 ?>
                        <tr>
                            <td>
                                <a class="btn btn-danger" href="deletecategory.php?id=<?php echo $row['CategoryID']; ?>" role="button">Delete</a>
                            </td>
                            <td>
                                <?php if(isset($row['CName'])){print_r($row['CName']);} ?>
                            </td>
                        </tr>
                        <?php
                            }
                        }
                        ?>

                </table>
            </div>
        </div>






        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
            crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
            crossorigin="anonymous"></script>
    </body>
    </html>